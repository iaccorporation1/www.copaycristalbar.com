ARCHIVOS LISTOS PARA GODADDY

1. Entra a GoDaddy.
2. Abre tu hosting o cPanel.
3. Ve a File Manager > public_html.
4. Sube todo el contenido de esta carpeta dentro de public_html.
5. Si ya existe un index.html anterior, reemplázalo.
6. Abre tu dominio y verifica la web.

ARCHIVOS PRINCIPALES:
- index.html
- styles.css
- carpeta assets

DATOS ACTUALES DEL SITIO:
- Nombre: Copa & Cristal Bar
- Ciudad: Chiclayo
- WhatsApp: 940 740 477
- Horario: 2:00 pm – 4:00 am

Si luego deseas cambiar textos o precios, edita index.html.
