# Copa & Cristal - versión final para Vercel

Sube este ZIP a Vercel.
Framework: Vite
Build Command: npm run build
Output Directory: dist

Este proyecto incluye vercel.json para evitar errores NOT_FOUND.
